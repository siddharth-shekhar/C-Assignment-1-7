﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace CSharp11

    {

        struct Books
        {
            public enum bookType
            {
                Magazine, Novel, ReferenceBook, Miscellaneous
            }

            private string _Title;
            private int _price;
            private int _bookId;
            private bookType _bookType;


            public string Title { get; set; }

            public int Price { get; set; }
            public int BookId { get; set; }
            public bookType BookType { get; set; }

        }
        class BookStructureAndEnum
        {
            public static void Main()
            {
                Books book = new Books();

                Console.Write("Get the Book Id :");
                book.BookId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Get the Book Title:");
                book.Title = (Console.ReadLine());

                Console.Write("Get the Book Price:");
                book.Price = Convert.ToInt32(Console.ReadLine());



                book.BookType = Books.bookType.Magazine;
                Console.WriteLine("------------");
                Console.WriteLine("------------");
                Console.WriteLine("The ID of Book :" + book.BookId);
                Console.WriteLine("The Title of the Book:" + book.Title);
                Console.WriteLine("The Price of the Book:" + book.Price);
                Console.WriteLine("The Type of the Book:" + book.BookType);
            }
        }
    }
}
