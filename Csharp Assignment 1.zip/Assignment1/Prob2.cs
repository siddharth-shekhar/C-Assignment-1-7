﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;

    class Circle
    {
        static double circumference(double a)
        {

            double PI = 3.1415;
            double circum = 2 * PI * a;
            return circum;
        }
        public static void Main()
        {

            double a;
            Console.Write("Enter the Radius: ");
            a = Convert.ToInt32(Console.ReadLine());
            double result =
                  Math.Round(circumference(a)
                            * 1000) / 1000.0;

            Console.WriteLine("Circumference = "
                                      + result);
        }
    }

}
