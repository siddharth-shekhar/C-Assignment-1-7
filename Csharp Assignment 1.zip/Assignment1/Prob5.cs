﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;

    namespace Structure
    {


        enum BookType : byte
        {
            Magazine = 10,
            Novel = 1,
            ReferenceBook = 100,
            Miscellaneous = 9
        }

        struct BOOK
        {
            public int Book_ID;
            public string Title;
            public short Price;
            public BookType header;


            public BOOK(int i, string s, short p, BookType hf)
            {
                Book_ID = i;
                Title = s;
                Price = p;
                header = hf;

            }
        }

        class MainClass
        {
            public static void Main(string[] args)
            {
                BOOK nat;
                nat.Book_ID = 40;
                nat.Title = "Nature";
                nat.Price = 250;
                nat.header = BookType.Novel;
                //Creating a Oject
                BOOK sam = new BOOK(50, "Sam", 1450, BookType.Magazine);

                Console.WriteLine("BookID is {0} ", sam.Book_ID);
                Console.WriteLine("Title is {0}", sam.Title);
                Console.WriteLine("Price is {0}", sam.Price);
                Console.WriteLine("Tyoe of the book is {0}", sam.header);
                //Creating a Space or a New Line
                Console.WriteLine("\n");

                Console.WriteLine("BookID is {0}", nat.Book_ID);
                Console.WriteLine("Title is {0}", nat.Title);
                Console.WriteLine("Price is {0}", nat.Price);
                Console.WriteLine("Tyoe of the book is {0}", nat.header);


            }
        }
    }
}
